/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Student_Table;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author princecalvinsagatwa
 */
public class StudentDAO {
    public void saveStudent(Student_Table student){
        //Create session
        Session ss=null;
        Transaction tr=null;
        try
        {
            ss=HibernateUtil.getSessionFactory().openSession();
            tr=ss.beginTransaction();
            ss.save(student);
            tr.commit();
            JOptionPane.showMessageDialog(null, "New Student has been saved successfully!", "Saving Agency", JOptionPane.INFORMATION_MESSAGE);
        }catch(HibernateException ex){
            if(tr!=null){
                tr.rollback();
            }
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }finally{
            if(ss!=null){
                ss.close();
            }
        }
    }
    
    public List<Student_Table> retrieveStudent(){
        List<Student_Table> students = new ArrayList<>();
        Session ss=null;
        try{
            ss=HibernateUtil.getSessionFactory().openSession();
            students = ss.createQuery("FROM Student_Table").list();
        }catch(HibernateException ex){
            JOptionPane.showMessageDialog(null, ex);
        }finally{
            if(ss!=null){
                ss.close();
            }
        }        
        return students;
    }
    
    public boolean updateStudent(Student_Table student){
        //Create session
        boolean result=false;
        Session ss=HibernateUtil.getSessionFactory().openSession();
        Transaction tr=ss.beginTransaction();
        ss.update(student);
        result=true;
        tr.commit();
        ss.close();
        return result;
    }
    
    public boolean deleteStudent(Student_Table student){
        //Create session
        boolean result=false;
        Session ss=HibernateUtil.getSessionFactory().openSession();
        Transaction tr=ss.beginTransaction();
        ss.delete(student);
        result=true;
        tr.commit();
        ss.close();
        return result;
    }
}
