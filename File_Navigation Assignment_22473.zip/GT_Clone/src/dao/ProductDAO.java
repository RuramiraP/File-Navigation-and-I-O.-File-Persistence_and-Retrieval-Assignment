/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.ProductTable;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author princecalvinsagatwa
 */
public class ProductDAO {
    public void saveProduct(ProductTable product){
        //Create session
        Session ss=null;
        Transaction tr=null;
        try
        {
            ss=HibernateUtil.getSessionFactory().openSession();
            tr=ss.beginTransaction();
            ss.save(product);
            tr.commit();
            JOptionPane.showMessageDialog(null, "New Product has been saved successfully!", "Saving Product", JOptionPane.INFORMATION_MESSAGE);
        }catch(HibernateException ex){
            if(tr!=null){
                tr.rollback();
            }
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }finally{
            if(ss!=null){
                ss.close();
            }
        }
        System.out.println("Done....");
    }
    
    public List<ProductTable> retrieveProduct(){
        List<ProductTable> products = new ArrayList<>();
        Session ss=null;
        try{
            ss=HibernateUtil.getSessionFactory().openSession();
            products = ss.createQuery("FROM ProductTable").list();
        }catch(HibernateException ex){
            JOptionPane.showMessageDialog(null, ex);
        }finally{
            if(ss!=null){
                ss.close();
            }
        }        
        return products;
    }
    
    public boolean updateProduct(ProductTable product){
        //Create session
        boolean result=false;
        Session ss=HibernateUtil.getSessionFactory().openSession();
        Transaction tr=ss.beginTransaction();
        ss.update(product);
        result=true;
        tr.commit();
        ss.close();
        return result;
    }
    
    public boolean deleteProduct(ProductTable product){
        //Create session
        boolean result=false;
        Session ss=HibernateUtil.getSessionFactory().openSession();
        Transaction tr=ss.beginTransaction();
        ss.delete(product);
        result=true;
        tr.commit();
        ss.close();
        return result;
    }
}
