/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Munyangeri Yvonne
 */
@Entity
@Table (name="student_table")
public class Student_Table {
    @Id
    @Column (name = "registration_no")
    private String regNo;
    private String firstname;
    private String lastname;
    private Date dob;
    private String phone_number;
    private byte[] id_pdf;
    
    
    //Empty Constructor
    public Student_Table() {
    }

    //Parametrized constructor
    public Student_Table(String regNo, String firstname, String lastname, Date dob, String phone_number, byte[] id_pdf) {
        this.regNo = regNo;
        this.firstname = firstname;
        this.lastname = lastname;
        this.phone_number = phone_number;
        this.dob = dob;
        this.id_pdf = id_pdf;
    }
    //Setter and getters
    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public byte[] getId_pdf() {
        return id_pdf;
    }

    public void setId_pdf(byte[] id_pdf) {
        this.id_pdf = id_pdf;
    }
    
}
