/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;


/**
 *
 * @author Munyangeri Yvonne
 */
    @Entity
    //@Table (name="product_table")
    public class ProductTable {

    @Id
    private String product_id;
    private String product_name;
    private Integer product_price;
    private String product_brand;
    private String product_desc;
    private Date reg_date;
    byte[] product_img;
    
    
    //Parametrized constructor
    public ProductTable(String product_id, String product_name, Integer product_price, String product_brand, String product_desc, Date reg_date, byte[] product_img) {    
        this.product_id = product_id;
        this.product_name = product_name;
        this.product_price = product_price;
        this.product_brand = product_brand;
        this.product_desc = product_desc;
        this.reg_date = reg_date;
        this.product_img = product_img;
    }

    //Empty Constructor
    public ProductTable() {
    }
    
    //Setter and Getter
    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public Integer getProduct_price() {
        return product_price;
    }

    public void setProduct_price(Integer product_price) {
        this.product_price = product_price;
    }

    public String getProduct_brand() {
        return product_brand;
    }

    public void setProduct_brand(String product_brand) {
        this.product_brand = product_brand;
    }

    public String getProduct_desc() {
        return product_desc;
    }

    public void setProduct_desc(String product_desc) {
        this.product_desc = product_desc;
    }

    public Date getReg_date() {
        return reg_date;
    }

    public void setReg_date(Date reg_date) {
        this.reg_date = reg_date;
    }

    public byte[] getProduct_img() {
        return product_img;
    }

    public void setProduct_img(byte[] product_img) {
        this.product_img = product_img;
    }
    
    
}
